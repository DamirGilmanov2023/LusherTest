# The Shaggy Dev Projects

This repository contains all of the projects from [shaggydev.com](https://shaggydev.com) and [Youtube](https://www.youtube.com/channel/UCoiLPC6AQHmJNSwdN1xmuWA).

To get started, clone the repo, find the project you're interested in, and import the `project.godot` file into Godot.
