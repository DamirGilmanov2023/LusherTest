## Godot version
Unless otherwise stated, all projects in this folder are built for Godot v3.4 or higher.